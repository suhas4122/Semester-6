//18CS10048 and 18CS30009

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>

const int MAX = 100;                //max buffer size

int main()
{
    int sockfd;                                
    char buffer[MAX];                               //buffer for storing replies from server         
    struct sockaddr_in servaddr;
    sockfd=socket(AF_INET,SOCK_STREAM,0);           // creating a tcp socket
    if(sockfd<0)        
    { 
        printf("Error in socket creation\n");       // sanity checking
        exit(1); 
    }
    memset(&servaddr,0,sizeof(servaddr));
    servaddr.sin_family=AF_INET;                    // IPv4
    servaddr.sin_port=htons(8084);                  // port no
    servaddr.sin_addr.s_addr=INADDR_ANY; 
    if(connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr))<0)      // establishing connection
    {
        close(sockfd);
        printf("Error in connection\n");            // sanity checking
        exit(-1);
    }
    scanf("%s",buffer);                         // filename as input
    size_t len = strlen(buffer)+1;
    send(sockfd,buffer,len,0);                  // requesting client for this file
    int ofd = open("output.txt",O_WRONLY|O_CREAT|O_TRUNC,0644);         // opening output file
    if(ofd<0)
    {
        printf("Error in output file creation\n");      // sanity checking
        close(sockfd);
        exit(-1);
    }
    int rec=0,flag=1,words=0,bytes=0;
    // loop till server sends replies in chunks
    int flagem = 1;         // for checking if an empty file is passed
    while((rec = recv(sockfd,buffer,MAX,0))>0)          // receiving replies from client in buffer
    {
        if(buffer[0]=='\0')
        {
            flagem = 0;
        }
        write(ofd,buffer,strlen(buffer));       // writing it to the output file
        int i = 0;
        while(i<rec && buffer[i]!='\0')         // iterating to check delimiters
        {
            if(buffer[i]==' '||buffer[i]=='\t'||buffer[i]=='\n'||buffer[i]==','||buffer[i]==';'||buffer[i]==':'||buffer[i]=='.'||buffer[i]=='\r') flag=1;
            else
            {
                if(flag)
                {
                    words++;        // on delimiter increase word count
                    flag=0;
                }
            }
            i++; bytes++;           // maintaining no of bytes received
        }
    }
    if(rec<=0 && bytes==0&&flagem)          // if no bytes received then file not present
    {
        printf("ERR 01: File Not Found\n");
        exit(-1);
    }
    printf("The file transfer is succesful, Size of the file = %d bytes, no. of words = %d\n",bytes,words);
    close(ofd);                 // closing output file and connection
    close(sockfd);
}