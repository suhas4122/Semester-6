//18CS10048 and 18CS30009

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>

const int MAX = 100;		// max buffer size

int main(){
	struct sockaddr_in add_serv, add_cli;
	int rec;
	int server_fd, socket_fd, len_client;
	char buffer[MAX];			//buffer to receive/send to client
	memset(&add_serv,0,sizeof(add_serv));
    memset(&add_cli,0,sizeof(add_cli));

	server_fd = socket(AF_INET, SOCK_STREAM, 0);  	//creatig socket
	if( server_fd < 0)
	{
		printf("Failed socket creation");
		exit(1);
	}

	add_serv.sin_port = htons(8084);
	add_serv.sin_family = AF_INET;
	add_serv.sin_addr.s_addr = INADDR_ANY;
	
	if( bind(server_fd, (struct sockaddr *)&add_serv, sizeof(add_serv)) < 0) 	// binding socket to server address
	{
		close(server_fd);
		printf("Failed binding");	
		exit(1);	
	}
	A:				// label for starting server process
		printf("Server is running now..\n");
		listen ( server_fd,1); 				//listening to a client
		len_client = sizeof(add_cli);		
		if ( (socket_fd = accept( server_fd, (struct sockaddr *)&add_cli, &len_client ) ) < 0 )	//accepting the connection 
		{
			printf("Failure in accept..try again \n");
			close(socket_fd);
			goto A;				// closed connection and go back to listening for a client
		}	
		rec = recv(socket_fd, buffer, MAX, 0);			// received filename from client
		buffer[rec] = '\0';
		int file_fd;
		if( (file_fd = open(buffer,O_RDONLY, 0)) < 0)	//opening file
		{
				printf( "File open failed.. try again \n");
				close(socket_fd);
				close(file_fd);
				goto A;			// closed connection, file and go back to listening for a client
		} 
		memset(&buffer,0,sizeof(buffer));
		while( ( rec = read(file_fd, buffer, MAX)) > 0 )		//reading from the file in buffers till an error or EOF
		{
			send( socket_fd, buffer, MAX, 0); 	// sending te buffer
			memset(&buffer,0,sizeof(buffer));
		}
		buffer[0]= '\0';	//sending an ending character for the file so that client can distinguish between empty file and FileNotFound
		send( socket_fd, buffer, MAX, 1); 	
		close(socket_fd);		//closed connection
		close(file_fd);			//closed file
		printf("Process completed for this client\n");		//completed the process for this client
	goto A;			//loop back
	return 0;
}