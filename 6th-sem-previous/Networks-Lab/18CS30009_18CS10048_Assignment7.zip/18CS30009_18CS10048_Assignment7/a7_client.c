//18CS10048 and 18CS30009

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>

const int MAX = 100;                // max buffer size
const int B = 20;                   // block size

int main()
{
    int sockfd;                                
    char buffer[MAX];                               //buffer for storing replies from server         
    struct sockaddr_in servaddr;
    sockfd=socket(AF_INET,SOCK_STREAM,0);           // creating a tcp socket
    if(sockfd<0)        
    { 
        printf("Error in socket creation\n");       // sanity checking
        exit(1); 
    }
    memset(&servaddr,0,sizeof(servaddr));
    servaddr.sin_family=AF_INET;                    // IPv4
    servaddr.sin_port=htons(8084);                  // port no
    servaddr.sin_addr.s_addr=INADDR_ANY; 
    if(connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr))<0)      // establishing connection
    {
        close(sockfd);
        printf("Error in connection\n");            // sanity checking
        exit(-1);
    }
    scanf("%s",buffer);                         // filename as input
    size_t len = strlen(buffer)+1;
    send(sockfd,buffer,len,0);                  // requesting client for this file
    int F_SIZE=0;
    recv(sockfd,buffer,MAX,0);  
    if(buffer[0]=='E')                          // when server sends file not found
    {
        printf("Error file not found\n");
        return 0;
    }
    if(buffer[0]=='L')                      // when server sends the file size
    {
        // printf("taking file size\n");
        recv(sockfd,buffer,MAX,0);
        F_SIZE = atoi(buffer);
        close(sockfd);      //closing the socket
        // printf("received size of file: %d \n",F_SIZE);
    }
    int ofd = open("output.txt",O_WRONLY|O_CREAT|O_TRUNC,0644);         // opening output file
    if(ofd<0)
    {
        printf("Error in output file creation\n");      // sanity checking
        close(sockfd);
        exit(-1);
    }
    int last_block=0,block_cnt=0;
    int tot = F_SIZE;                                   // temporary for calculation
    while(1)
    {
        memset(buffer,0,strlen(buffer));                // clearing the buffer
        if(tot<=0) break;
        if(tot%B==tot)                                  // condition if its the last block
        {
            recv(sockfd,buffer,F_SIZE%B,MSG_WAITALL);   // wait for exactly F_SIZE%B 
            block_cnt++;
            last_block=strlen(buffer);                  // update size of last block
            write(ofd,buffer,strlen(buffer));
            break;
        }
        else                                            // else a block of size B
        {
            recv(sockfd,buffer,B,MSG_WAITALL);          // so wait for B
            write(ofd,buffer,strlen(buffer));
            block_cnt++;
            tot-=B;                                     // update file size left
        }
    }
    printf("The file transfer is succesful. Total number of blocks received = %d, Last block size = %d\n",block_cnt,last_block);
    close(ofd);                 // closing output file and connection
    close(sockfd);
}