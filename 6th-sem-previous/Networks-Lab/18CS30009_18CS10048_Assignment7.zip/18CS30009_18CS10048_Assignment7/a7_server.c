//18CS10048 and 18CS30009

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>

const int MAX = 100;		// max buffer size
const int B = 20;                   // block size


char *itoa(int num, char *str)			//function for converting integer to char*
{
        if(str == NULL)
        {
                return NULL;
        }
        sprintf(str, "%d", num);
        return str;
}

int main(){
	struct sockaddr_in add_serv, add_cli;
	int rec;
	int server_fd, socket_fd, len_client;
	char buffer[MAX];			//buffer to receive/send to client
	char filename[MAX];			//to store filename
	memset(&add_serv,0,sizeof(add_serv));
    memset(&add_cli,0,sizeof(add_cli));

	server_fd = socket(AF_INET, SOCK_STREAM, 0);  	//creating socket
	if( server_fd < 0)
	{
		printf("Failed socket creation");
		exit(1);
	}

	add_serv.sin_port = htons(8084);
	add_serv.sin_family = AF_INET;
	add_serv.sin_addr.s_addr = INADDR_ANY;
	
	if( bind(server_fd, (struct sockaddr *)&add_serv, sizeof(add_serv)) < 0) 	// binding socket to server address
	{
		close(server_fd);
		printf("Failed binding");	
		exit(1);	
	}
	A:				// label for starting server process
		printf("Server is running now..\n");
		listen ( server_fd,1); 				//listening to a client
		len_client = sizeof(add_cli);		
		if ( (socket_fd = accept( server_fd, (struct sockaddr *)&add_cli, &len_client ) ) < 0 )	//accepting the connection 
		{
			printf("Failure in accept..try again \n");
			close(socket_fd);
			goto A;				// closed connection and go back to listening for a client
		}	
		rec = recv(socket_fd, filename, MAX, 0);			// received filename from client
		filename[rec] = '\0';
		int file_fd;
		if( (file_fd = open(filename,O_RDONLY, 0)) < 0)	//opening file
		{
				buffer[0]='E';
				buffer[1]='\0';
				send( socket_fd, buffer, MAX, 0);			// sent E if error in opening file
				close(socket_fd);
				close(file_fd);
				goto A;			// closed connection, file and go back to listening for a client
		} 
		buffer[0]='L';
		buffer[1]='\0';
		send( socket_fd, buffer, MAX, 0);			//sent L if found the file
		off_t fsize;
		fsize = lseek(file_fd, 0, SEEK_END);		//finding file size 
		int filesize  = (int) fsize;
	    itoa (filesize,buffer);						//converting the filesize from int to char* for sending to the client
		send( socket_fd, buffer,4,0);
		close(file_fd);								//closed this connection
		int file_fd2 = open(filename,O_RDONLY, 0);	//opened the file again to fix the curson
		memset(&buffer,0,sizeof(buffer));
		int count =0;		// to store count of send operations
		// printf("filesize: %d, blocksize: %d, numblocks: %d\n",filesize,B, (filesize+B-1)/B );
		while(count<filesize/B)		//reading from the file in buffers till we can send a complete block
		{
			count++;
			rec = read(file_fd2, buffer, B);
			// printf("sending:\n%s\n",buffer);
			send( socket_fd, buffer, B, 0); 	// sending te buffer
			memset(&buffer,0,sizeof(buffer));
		}
		if(filesize%B)		// if one last block of size filesize%B is left
		{
			rec = read(file_fd2, buffer, filesize%B);	
			// printf("sending:\n%s\n",buffer);	
			send( socket_fd, buffer,filesize%B, 0); 	// sending the buffer
		}
		memset(&buffer,0,sizeof(buffer));
		buffer[0]= '\0';	//sending an ending character for the file so that client can distinguish between empty file and FileNotFound
		send( socket_fd, buffer, MAX, 1); 	
		close(socket_fd);		//closed connection
		close(file_fd2);			//closed file
		printf("Process completed for this client\n");		//completed the process for this client
	goto A;			//loop back
	return 0;
}