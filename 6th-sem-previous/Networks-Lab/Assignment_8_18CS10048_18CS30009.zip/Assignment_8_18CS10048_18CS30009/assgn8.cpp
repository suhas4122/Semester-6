// 18CS30009 18CS10048


#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <iostream>
#include <ctype.h>
#include <bits/stdc++.h>

using namespace std;

#define MAX 64                                          // maximum buffer size

int main(int argc, char const **argv)
{
    if(argc!=2)                                         // check if the command line input is in the required format
    {
        printf("Error!! Wrong Command\n");
        exit(-1);
    }

    int serverfd;                                       // file descriptor for listening socket
    struct sockaddr_in peer,myself,frnd;                // sockets for myself, peer and friends
    struct hostent *server;
    int tem=1;

    int port = atoi(argv[1]);                           // listening port

    char *static_table = (char *)"user_info.txt";       // file storing static information
    char message[MAX],sending_message[MAX];             // buffers for messages

    timeval timeout;                                    // to set timeout for select syscall
    timeout.tv_sec=1; timeout.tv_usec=0;

    map<string,pair<string,int> > predefined_table;                     // storing the static table information for each user
    map<int, pair< pair<string,int>, time_t > > active_connections;     // storing the active connections with their timestamps
    vector<int> active_sockets;             // list of active sockets

    ifstream in;                            // populating the static table from the file
    in.open(static_table);
    string name,address; int p;
    pair<string,int> row;
    while(in >> name >> address >> p)
    {
        row = make_pair(address,p);
        predefined_table[name]=row;
    }

    if((serverfd = socket(AF_INET, SOCK_STREAM, 0))==-1)    // creating the listening socket
    {
        printf("Error!! Listening socket not created\n");
        exit(-1);
    }

    myself.sin_family = AF_INET;                        // bind the listening socket to listening port
    myself.sin_addr.s_addr = INADDR_ANY;
    myself.sin_port = htons(port);
    setsockopt(serverfd, SOL_SOCKET, SO_REUSEPORT, & tem, sizeof(tem));
    if(bind(serverfd,(struct sockaddr *)&myself, sizeof(myself))==-1)   printf("Error!! Binding error\n");
    if(listen(serverfd,5)==-1) printf("Error!! Problem in listen\n");   // listen for 5 users at max

    fd_set collection,temp;                         // collection of file desccriptors
    FD_ZERO(&collection); FD_ZERO(&temp);
    FD_SET(serverfd,&collection); FD_SET(0,&collection);       // adding STDIN and listening socket to the collection
    int fd_max = max(serverfd,0);               // finding the maximum file descriptor in the collection

    cout<<"Chat started"<<endl;
    while(1)
    {
        temp = collection;
        if(select(fd_max+1,&temp,NULL,NULL,&timeout)>=0)        // select system call
        {
            for(int i=0;i<=fd_max;i++)          // iterating till max fd
            {
                if(FD_ISSET(i,&temp))           // the fd returned by select should be in the active sockets
                {
                    if(i==0)           // if the fd selected is STDIN then some message is to be sent by the user
                    {
                        bzero(sending_message,MAX);
                        fgets(sending_message,MAX,stdin);       // take the sending message
                        char name[MAX];                         // for name of the peer to which it is to be sent
                        int count = 0;
                        int marker = -1;                        // for input format
                        for(int k=0; k<strlen(sending_message); k++)
                        {
                            if(sending_message[k] == '/')
                            {
                                marker=k+1;
                                break;
                            }
                            else
                            {
                                name[count] = sending_message[k];
                                count++;
                            }
                        }
                        if(marker<0)
                        {
                            printf("Error!! Wrong format\n");
                            continue;
                        }
                        bzero(message, MAX);
                        strcpy(message, &sending_message[marker]);
                        name[count] = '\0';
                        string user(name);
                        pair<string,int> sendinfo;              // find the peer information in the static table
                        if(predefined_table.find(user) != predefined_table.end())  sendinfo = predefined_table[user];
                        else
                        {
                            printf("Error!! User not in predefined table\n");
                            continue;
                        }
                        int sockfd = -1;                    // check if the connection is already active
                        for(auto it = active_connections.begin(); it != active_connections.end(); it++)
                        {
                            pair< pair<string,int>, time_t > temp = it->second;
                            if(temp.first.first == sendinfo.first && temp.first.second == sendinfo.second)
                            {
                                sockfd = it->first;
                                break;
                            }
                        }
                        if(sockfd != -1)        // if the connection is already active then just send the message
                        {
                            int x = send(sockfd,message, MAX, 0);
                            if(x<0) printf("Error!! Couldn't send your message\n");
                            time(&(active_connections[sockfd].second));         // add the timestamp of the connection
                        }
                        else                // create a new connection to the peer
                        {
                            sockfd = socket(AF_INET, SOCK_STREAM, 0);
                            if(sockfd<0) printf("Error!! Couldn't connect\n");
                            const char* hostname = (sendinfo.first).c_str();
                            server = gethostbyname(hostname);       // find the host using IP
                            if (server == NULL)
                            {
                                printf("Error!! Host not found - %s\n",hostname);
                                continue;
                            }
                            bzero((char *) &peer, sizeof(peer));
                            peer.sin_family = AF_INET;
                            bcopy((char *)server->h_addr,(char *)&peer.sin_addr.s_addr, server->h_length);
                            peer.sin_port = htons(sendinfo.second);
                            if (connect(sockfd, (struct sockaddr*)&peer, sizeof(peer)) < 0)     // connect to peer
                            {
                            	cout << "Error!! Couldn't connect to " << user << endl;
                            	fflush(stdout);
                            	continue;
                            }
                            active_sockets.push_back(sockfd);           // add the new socket to the list of active sockets
                            pair< pair<string,int>, time_t > temp2;
                            temp2.first = sendinfo;
                            time(&temp2.second);
                            active_connections[sockfd] = temp2;         // also add the new connection to the active connections 
                            FD_SET(sockfd,&collection);                 // add the socket fd to the collection
                            fd_max = max(fd_max, sockfd);               // update the max fd
                            int x = send(sockfd,message,MAX,0);         // and send the message now
                            if(x<0) printf("Error!! Couldn't send\n");
                        }
                    }
                    else if(i==serverfd)             // if the fd is the listening fd then there is a connection request
                    {
                        socklen_t frndlength = sizeof(frnd);
                        int newfd = accept(serverfd,(struct sockaddr*)&frnd, &frndlength);  // accept the connection from the friend
                        if(newfd<0) printf("Error!! Couldn't accept\n");
                        else
                        {
                            FD_SET(newfd,&collection);          // add it to the collection
                            fd_max = max(fd_max, newfd);        // update the max fd
                            printf("%s Connected\n", inet_ntoa(frnd.sin_addr));
                        }
                    }
                    else                        // a friend sent a message to you
                    {
                        bzero(message,MAX);
                        int x = recv(i,message,MAX,0);      // receive the message
                        if(x<0) printf("Error!!!\n");
                        else if(x==0)                   // friend closed the connection
                        {
                            close(i);
                            FD_CLR(i,&collection);
                        }
                        else
                        {
                            socklen_t frndlength = sizeof(frnd);            // find the friend's name
                            if(getpeername(i,(struct sockaddr *)&frnd, &frndlength)>= 0)
                            {
                                for(auto it = predefined_table.begin(); it!= predefined_table.end(); it++)
                                {
                                    if((it->second).first == inet_ntoa(frnd.sin_addr))
                                    {
                                        cout << it->first << ": ";
                                        break;
                                    }
                                }
                            }
                            printf("%s", message);          // print the message
                        }
                    }
                }
            }
        }
        // close any active socket that has timedout
        time_t curr;
        for(int k=0; k<active_sockets.size(); k++)
        {
            time(&curr);
            if(curr - active_connections[active_sockets[k]].second >= 20)
            {
                cout << "Closing active socket to " << active_connections[active_sockets[k]].first.first << endl;
                close(active_sockets[k]);
                FD_CLR(active_sockets[k], &collection);
                auto it = active_connections.find(active_sockets[k]);
                active_connections.erase(it);
                active_sockets.erase(active_sockets.begin() + k);
            }
        }
    }

}