sudo ip netns add Vnet0                                      # Creating Vnet0 network namespace
sudo ip netns add Vnet1                                      # Creating Vnet1 network namespace

sudo ip link add Veth0 type veth peer name Veth1             # Creating Veth0 and Veth1 interfaces

sudo ip link set Veth0 netns Vnet0                           # Assigning Veth0 to Vnet0
sudo ip netns exec Vnet0 ip addr add 10.1.1.0/24 dev Veth0   # Assigning IP 10.1.1.0/24 to Veth0
sudo ip netns exec Vnet0 ip link set dev Veth0 up            # Bring up the Veth0 interface

sudo ip link set Veth1 netns Vnet1                           # Assigning Veth1 to Vnet1
sudo ip netns exec Vnet1 ip addr add 10.1.2.0/24 dev Veth1   # Assigning IP 10.1.2.0/24 to Veth1
sudo ip netns exec Vnet1 ip link set dev Veth1 up            # Bring up the Veth1 interface

sudo ip -n Vnet0 route add 10.1.2.0/24 dev Veth0             # Adding route to 10.1.2.0/24 in route table of Vnet0
sudo ip -n Vnet1 route add 10.1.1.0/24 dev Veth1             # Adding route to 10.1.1.0/24 in route table of Vnet1

sudo ip netns exec Vnet0 ping -c5 10.1.2.0                   # Pinging from Vnet0 to Vnet1
sudo ip netns exec Vnet1 ping -c5 10.1.1.0                   # Pinging from Vnet1 to Vnet0
