# 18CS10048
# Sahil Jindal

sudo ip -all netns delete										# Deleting existing namespaces if any
sudo ip netns add virtual0                                      # Created network namespace virtual1
sudo ip netns add virtual1                                      # Created network namespace virtual2

sudo ip link add veth0 type veth peer name veth1             	# Created veth0 and veth1 

sudo ip link set veth0 netns virtual0                           # Linking veth0 and virtual0
sudo ip link set veth1 netns virtual1                           # Linking veth1 and virtual1
sudo ip netns exec virtual0 ip addr add 10.1.1.0/24 dev veth0   # Assigned IP 10.1.1.0/24 to virtual0
sudo ip netns exec virtual0 ip link set dev veth0 up            # Turn up veth0 
sudo ip -n virtual0 route add 10.1.2.0/24 dev veth0             # Added route to 10.1.2.0/24 in the route table of virtual0
sudo ip netns exec virtual1 ip addr add 10.1.2.0/24 dev veth1   # Assigned IP 10.1.1.0/24 to virtual1
sudo ip netns exec virtual1 ip link set dev veth1 up            # Turn up veth1 
sudo ip -n virtual1 route add 10.1.1.0/24 dev veth1             # Added route to 10.1.1.0/24 in the route table of virtual1

#Command to ping the networks
# sudo ip netns exec virtual0 ping -c4 10.1.2.0                   # virtual0 to virtual1
# sudo ip netns exec virtual1 ping -c4 10.1.1.0                   # virtual1 to virtual0
