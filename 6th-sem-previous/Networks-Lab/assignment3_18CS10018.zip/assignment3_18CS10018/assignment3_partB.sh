# 18CS10048
# Sahil Jindal

sudo ip -all netns delete								# Deleting existing namespaces if any

sudo ip netns add R         							#creating network namespace R
sudo ip netns add H1         							#creating network namespace H1                                   
sudo ip netns add H2         							#creating network namespace H2                                       
sudo ip netns add H3         							#creating network namespace H3	

sudo ip link add veth1 type veth peer name veth2        # Created veth1 and veth2
sudo ip link add veth6 type veth peer name veth3		# Created veth3 and veth6
sudo ip link add veth5 type veth peer name veth4		# Created veth4 and veth5 

sudo ip link set veth1 netns H1							# Linking veth1 and H1
sudo ip link set veth2 netns R							# Linking veth2 and R

sudo ip link set veth6 netns H2							# Linking veth6 and H2
sudo ip link set veth3 netns R							# Linking veth3 and R

sudo ip link set veth5 netns H3							# Linking veth5 and H3
sudo ip link set veth4 netns R							# Linking veth4 and R

sudo ip netns exec H1 ip addr add 10.0.10.48/24 dev veth1        # Assigning the IPs
sudo ip netns exec R ip addr add 10.0.10.1/24 dev veth2
sudo ip netns exec H2 ip addr add 10.0.20.48/24 dev veth6
sudo ip netns exec R ip addr add 10.0.20.1/24 dev veth3
sudo ip netns exec H3 ip addr add 10.0.30.48/24 dev veth5
sudo ip netns exec R ip addr add 10.0.30.1/24 dev veth4

sudo ip netns exec R ip link add name BR type bridge            # Creating the bridge
sudo ip netns exec R ip link set BR up                          # Turn up the bridge 
sudo ip netns exec R ip link set veth2 master BR                # Linking veth2 to the bridge
sudo ip netns exec R ip link set veth3 master BR                # Linking veth3 to the bridge
sudo ip netns exec R ip link set veth4 master BR                # Linking veth4 to the bridge

sudo ip netns exec H1 ip link set dev veth1 up                  # Turn up veth1
sudo ip netns exec R ip link set dev veth2 up					# Turn up veth2
sudo ip netns exec R ip link set dev veth3 up					# Turn up veth3
sudo ip netns exec R ip link set dev veth4 up					# Turn up veth4
sudo ip netns exec H3 ip link set dev veth5 up					# Turn up veth5
sudo ip netns exec H2 ip link set dev veth6 up					# Turn up veth6



sudo ip netns exec H1 ip route add default via 10.0.10.48 dev veth1          # Adding entries in the routing table 
sudo ip netns exec R ip route add 10.0.10.1 dev veth2
sudo ip netns exec R ip route add 10.0.20.1 dev veth3
sudo ip netns exec R ip route add 10.0.30.1 dev veth4
sudo ip netns exec H3 ip route add default via 10.0.30.48 dev veth5
sudo ip netns exec H2 ip route add default via 10.0.20.48 dev veth6



sudo ip netns exec R sysctl -w net.ipv4.ip_forward=1            # Enabled IP forwarding at R

#Commands to ping various networks 
# sudo ip netns exec H1 ping -c4 10.0.20.48                        
# sudo ip netns exec H1 ping -c4 10.0.30.48
# sudo ip netns exec H2 ping -c4 10.0.10.48
# sudo ip netns exec H2 ping -c4 10.0.30.48
# sudo ip netns exec H3 ping -c4 10.0.10.48
# sudo ip netns exec H3 ping -c4 10.0.20.48
