#!/bin/sh
#Sahil Jindal
#18CS10048
#Assignment 4 Networks
#cmd to run the file: sudo bash assignment4_partA.sh

# run "sudo ip -all netns delete" 3-4 times if there is a file exists error. 	
# ip -all netns delete	# deleting existing namespaces if any

ip netns add N1			# creating namespaces
ip netns add N2
ip netns add N3
ip netns add N4
ip netns add N5
ip netns add N6


ip link add V1 type veth peer name V2 # creating veth connections
ip link add V3 type veth peer name V4
ip link add V5 type veth peer name V6
ip link add V7 type veth peer name V8
ip link add V9 type veth peer name V10
ip link add V11 type veth peer name V12


# assigning veths to the namespaces

ip link set V1 netns N1
ip link set V2 netns N2
ip link set V3 netns N2
ip link set V4 netns N3
ip link set V5 netns N3
ip link set V6 netns N4
ip link set V7 netns N4
ip link set V8 netns N5
ip link set V9 netns N5
ip link set V10 netns N6
ip link set V11 netns N6
ip link set V12 netns N1

# adding ips to the veths
ip -n N1 addr add 10.0.10.48/24 dev V1
ip -n N2 addr add 10.0.10.49/24 dev V2
ip -n N2 addr add 10.0.20.48/24 dev V3
ip -n N3 addr add 10.0.20.49/24 dev V4
ip -n N3 addr add 10.0.30.48/24 dev V5
ip -n N4 addr add 10.0.30.49/24 dev V6
ip -n N4 addr add 10.0.40.48/24 dev V7
ip -n N5 addr add 10.0.40.49/24 dev V8
ip -n N5 addr add 10.0.50.48/24 dev V9
ip -n N6 addr add 10.0.50.49/24 dev V10
ip -n N6 addr add 10.0.60.48/24 dev V11
ip -n N1 addr add 10.0.60.49/24 dev V12

# turning up the veths
ip -n N1 link set dev V1 up
ip -n N2 link set dev V2 up
ip -n N2 link set dev V3 up
ip -n N3 link set dev V4 up
ip -n N3 link set dev V5 up
ip -n N4 link set dev V6 up
ip -n N4 link set dev V7 up
ip -n N5 link set dev V8 up
ip -n N5 link set dev V9 up
ip -n N6 link set dev V10 up
ip -n N6 link set dev V11 up
ip -n N1 link set dev V12 up

#turing up the los
ip -n N1 link set dev lo up
ip -n N2 link set dev lo up
ip -n N3 link set dev lo up
ip -n N4 link set dev lo up
ip -n N5 link set dev lo up
ip -n N6 link set dev lo up

# adding routes
ip -n N1 route add 10.0.20.0/24 via 10.0.10.49 dev V1
ip -n N1 route add 10.0.30.0/24 via 10.0.10.49 dev V1
ip -n N1 route add 10.0.40.0/24 via 10.0.10.49 dev V1
ip -n N1 route add 10.0.50.0/24 via 10.0.10.49 dev V1
ip -n N2 route add 10.0.30.0/24 via 10.0.20.49 dev V3
ip -n N2 route add 10.0.40.0/24 via 10.0.20.49 dev V3
ip -n N2 route add 10.0.50.0/24 via 10.0.20.49 dev V3
ip -n N2 route add 10.0.60.0/24 via 10.0.20.49 dev V3
ip -n N3 route add 10.0.10.0/24 via 10.0.30.49 dev V5
ip -n N3 route add 10.0.40.0/24 via 10.0.30.49 dev V5
ip -n N3 route add 10.0.50.0/24 via 10.0.30.49 dev V5
ip -n N3 route add 10.0.60.0/24 via 10.0.30.49 dev V5
ip -n N4 route add 10.0.10.0/24 via 10.0.40.49 dev V7
ip -n N4 route add 10.0.20.0/24 via 10.0.40.49 dev V7
ip -n N4 route add 10.0.50.0/24 via 10.0.40.49 dev V7
ip -n N4 route add 10.0.60.0/24 via 10.0.40.49 dev V7
ip -n N5 route add 10.0.10.0/24 via 10.0.50.49 dev V9
ip -n N5 route add 10.0.20.0/24 via 10.0.50.49 dev V9
ip -n N5 route add 10.0.30.0/24 via 10.0.50.49 dev V9
ip -n N5 route add 10.0.60.0/24 via 10.0.50.49 dev V9
ip -n N6 route add 10.0.10.0/24 via 10.0.60.49 dev V11
ip -n N6 route add 10.0.20.0/24 via 10.0.60.49 dev V11
ip -n N6 route add 10.0.30.0/24 via 10.0.60.49 dev V11
ip -n N6 route add 10.0.40.0/24 via 10.0.60.49 dev V11

# forwarding ip
ip netns exec N1 sysctl -w net.ipv4.ip_forward=1
ip netns exec N2 sysctl -w net.ipv4.ip_forward=1
ip netns exec N3 sysctl -w net.ipv4.ip_forward=1
ip netns exec N4 sysctl -w net.ipv4.ip_forward=1
ip netns exec N5 sysctl -w net.ipv4.ip_forward=1
ip netns exec N6 sysctl -w net.ipv4.ip_forward=1

ip netns exec N1 traceroute 10.0.50.48	# trace routes
ip netns exec N3 traceroute 10.0.50.48
ip netns exec N3 traceroute 10.0.10.48

# pinging all the combinations 
for x in {10,20,30,40,50,60}
do
	for y in {48,49}
	do
		ip netns exec N1 ping -c3 10.0."$x"."$y"
		ip netns exec N2 ping -c3 10.0."$x"."$y"
		ip netns exec N3 ping -c3 10.0."$x"."$y"
		ip netns exec N4 ping -c3 10.0."$x"."$y"
		ip netns exec N5 ping -c3 10.0."$x"."$y"
		ip netns exec N6 ping -c3 10.0."$x"."$y"
	done
done

exit